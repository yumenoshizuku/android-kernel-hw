/*
 * NAME, etc.
 *
 * sync.c
 *
 * Synchronization routines for SThread
 */

#define _REENTRANT

#include <stdlib.h>
#include "sthread.h"


/*
 * semaphore routines
 */
int sthread_sem_init(sthread_sem_t *sem, int count)
{
	if(count < 0)
		return -1;
	sem->lock = 0;
	sem->cnt = count;
	sem->blocking = 0;
	int i;
	for(i = 0; i < 100; i++)
		sem->blockthr[i] = 0;
	return 0;
}

int sthread_sem_destroy(sthread_sem_t *sem)
{
	if(sem == NULL)
		return -1;
	sem = NULL;
	return 0;
}

int sthread_sem_down(sthread_sem_t *sem)
{
	while(test_and_set((volatile long unsigned int *)sem)) ;
	if(sem->cnt <= 0) {
		struct sthread_struct *self = sthread_self();
		int i;
		for(i = 0; i < sem->blocking - 1; i++)
			if(sem->blockthr[i] == self) {
				sem->lock = 0;
				return -1;
			}
		sem->blocking += 1;
		sem->blockthr[sem->blocking - 1] = self;
		sem->lock = 0;
		sthread_suspend();
	}
	else {
		sem->cnt -= 1;
		sem->lock = 0;
	}
	return 0;
}

int sthread_sem_try_down(sthread_sem_t *sem)
{
	while(test_and_set((volatile long unsigned int *)sem)) ;
	if(sem->cnt > 0) {
		sem->cnt -= 1;
		sem->lock = 0;
		return 0;
	}
	else {
		sem->lock = 0;
		return -1;
	}
}

int sthread_sem_up(sthread_sem_t *sem)
{
	while(test_and_set((volatile long unsigned int *)sem)) ;
	if(sem->blocking > 0) {
		struct sthread_struct *wakethr;
		wakethr = sem->blockthr[sem->blocking - 1];
		sem->blockthr[sem->blocking - 1] = 0;
		sem->blocking -= 1;
		sem->lock = 0;
		sthread_wake(wakethr);
		return 0;
	}
	else {
		sem->cnt += 1;
		sem->lock = 0;
		return 0;
	}
}
